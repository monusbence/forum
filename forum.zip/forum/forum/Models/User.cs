﻿using Microsoft.AspNetCore.Identity;

namespace forum.Models
{
    public class User : IdentityUser
    {
        string? VezetekNev { get; set; }
        string? KeresztNev { get; set; }
    }
}
